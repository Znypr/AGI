package main;

public interface TicTacToeLogic {

    public Result setChip(Player chip, int column, int row);

}
