package main;

public enum Player {

    BLUE,
    RED,
}
