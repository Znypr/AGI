package main;

public enum Result {

    NOTHING,
    TIE,
    ERROR,
    WIN_BLUE,
    WIN_RED,
}
