package main;

public class Logic implements FourWinsLogic {

    private Player[][] board = new Player[7][6];
    private int counter = 0;

    @Override
    public Result throwChip(Player chip, int column) {

        if(ifCheckOutOfBound(column))
            return Result.ERROR;

        int row = insert(chip,column);
        if(row < 0) {
            return Result.ERROR;
        }

        if (checkWinHorizontal(row)) {
            if (chip == Player.BLUE) {
                return Result.WIN_BLUE;
            } else {
                return Result.WIN_RED;
            }
        }

        if (checkWinVertical(column)) {
            if (chip == Player.BLUE) {
                return Result.WIN_BLUE;
            } else {
                return Result.WIN_RED;
            }
        }

        if (checkWinDiagonal(chip, row, column)) {
            if (chip == Player.BLUE) {
                return Result.WIN_BLUE;
            } else {
                return Result.WIN_RED;
            }
        }

        if (counter==42)
            return Result.TIE;

        return Result.NOTHING;
    }


    private int insert(Player chip, int column) {
        for(int i=0; i<6; i++) {
            if(board[column][i] == null) {
                board[column][i] = chip;
                counter++;
                return i;
            }
        }

        return -1;
    }

    private boolean ifCheckOutOfBound(int column){
        return column < 0 || column > 6;
    }

    private boolean checkWinHorizontal(int row) {
        return board[0][row] == Player.BLUE &&
                board[1][row] == Player.BLUE &&
                board[2][row] == Player.BLUE &&
                board[3][row] == Player.BLUE
                ||board[1][row] == Player.BLUE &&
                board[2][row] == Player.BLUE &&
                board[3][row] == Player.BLUE &&
                board[4][row] == Player.BLUE
                ||board[2][row] == Player.BLUE &&
                board[3][row] == Player.BLUE &&
                board[4][row] == Player.BLUE &&
                board[5][row] == Player.BLUE
                ||board[3][row] == Player.BLUE &&
                board[4][row] == Player.BLUE &&
                board[5][row] == Player.BLUE &&
                board[6][row] == Player.BLUE;
    }

    private boolean checkWinVertical(int column) {

        return board[column][0] == Player.BLUE &&
                board[column][1] == Player.BLUE &&
                board[column][2] == Player.BLUE &&
                board[column][3] == Player.BLUE
                || board[column][2] == Player.BLUE &&
                board[column][3] == Player.BLUE &&
                board[column][4] == Player.BLUE &&
                board[column][5] == Player.BLUE
                || board[column][1] == Player.BLUE &&
                board[column][2] == Player.BLUE &&
                board[column][3] == Player.BLUE &&
                board[column][4] == Player.BLUE;
    }

    private boolean checkWinDiagonal(Player chip, int row, int column){

        int counter = 1;
        for(int i = 1; i < 4;i++){
            if (column-i >= 0 && row-i >= 0) {
              if(board[column-i][row-i] == chip){
                  counter += 1;
              }
            }
        }

        if(counter==4) {
            return true;
        }

        counter = 1;
        for(int i = 1; i < 4;i++){
            if (column+i < 7 && row+i < 6) {
                if(board[column+i][row+i] == chip){
                    counter += 1;
                }
            }
        }

        if(counter==4) {
            return true;
        }

        counter = 1;
        for(int i = 1; i < 4;i++){
            if (column - i >= 0 && row+i < 6) {
                if(board[column-i][row+i] == chip){
                    counter += 1;
                }
            }
        }

        if(counter==4) {
            return true;
        }

        counter = 1;
        for(int i = 1; i < 4;i++){
            if (column + i < 7 && row-i >= 0) {
                if(board[column+i][row-i] == chip){
                    counter += 1;
                }
            }
        }

        return counter == 4;
    }

}