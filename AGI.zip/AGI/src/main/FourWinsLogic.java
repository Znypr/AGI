package main;

public interface FourWinsLogic {

    public Result throwChip(Player chip, int column);

}
